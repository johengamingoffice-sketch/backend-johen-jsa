<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('freelances', function (Blueprint $table) {
            $table->id();
            $table->string('nama');
            $table->string('host_position');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('freelances');
    }
};
